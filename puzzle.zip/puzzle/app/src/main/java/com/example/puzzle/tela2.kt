package com.example.puzzle
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView

class tela2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tela2)


        val imageViewPart2: ImageView = findViewById(R.id.imageViewPart2)
        val imageViewPart3: ImageView = findViewById(R.id.imageViewPart3)
        val imageViewPart4: ImageView = findViewById(R.id.imageViewPart4)
        val imageViewPart1: ImageView = findViewById(R.id.imageViewPart1)
        val imageViewPart5: ImageView = findViewById(R.id.imageViewPart5)
        val imageViewPart6: ImageView = findViewById(R.id.imageViewPart6)
        val imageViewPart7: ImageView = findViewById(R.id.imageViewPart7)
        val imageViewPart8: ImageView = findViewById(R.id.imageViewPart8)
        val imageViewPart9: ImageView = findViewById(R.id.imageViewPar9)

        imageViewPart1.setOnClickListener {
            imageViewPart1.rotation = (imageViewPart1.rotation + 90) % 360
        }
        imageViewPart2.setOnClickListener {
            imageViewPart2.rotation = (imageViewPart2.rotation + 90) % 360
        }
        imageViewPart3.setOnClickListener {
            imageViewPart3.rotation = (imageViewPart3.rotation + 90) % 360
        }
        imageViewPart4.setOnClickListener {
            imageViewPart4.rotation = (imageViewPart4.rotation + 90) % 360
        }
        imageViewPart5.setOnClickListener {
            imageViewPart1.rotation = (imageViewPart1.rotation + 90) % 360
        }
        imageViewPart6.setOnClickListener {
            imageViewPart2.rotation = (imageViewPart2.rotation + 90) % 360
        }
        imageViewPart7.setOnClickListener {
            imageViewPart3.rotation = (imageViewPart3.rotation + 90) % 360
        }
        imageViewPart8.setOnClickListener {
            imageViewPart4.rotation = (imageViewPart4.rotation + 90) % 360
        }
        imageViewPart9.setOnClickListener {
            imageViewPart4.rotation = (imageViewPart4.rotation + 90) % 360
        }
    }

    fun isPuzzleCorrect(): Boolean {
        val imageViewPart1 = findViewById<ImageView>(R.id.imageViewPart1)
        val imageViewPart2 = findViewById<ImageView>(R.id.imageViewPart2)
        val imageViewPart3 = findViewById<ImageView>(R.id.imageViewPart3)
        val imageViewPart4 = findViewById<ImageView>(R.id.imageViewPart4)


        return imageViewPart1.rotation == 0f &&
                imageViewPart2.rotation == 0f &&
                imageViewPart3.rotation == 0f &&
                imageViewPart4.rotation == 0f
    }
}