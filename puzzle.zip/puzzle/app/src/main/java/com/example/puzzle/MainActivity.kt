package com.example.puzzle
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val imageViewPart2: ImageView = findViewById(R.id.imageViewPart2)
        val imageViewPart3: ImageView = findViewById(R.id.imageViewPart3)
        val imageViewPart4: ImageView = findViewById(R.id.imageViewPart4)
        val imageViewPart1: ImageView = findViewById(R.id.imageViewPart1)

        imageViewPart1.setOnClickListener {
            imageViewPart1.rotation = (imageViewPart1.rotation + 90) % 360
        }
        imageViewPart2.setOnClickListener {
            imageViewPart2.rotation = (imageViewPart2.rotation + 90) % 360
        }
        imageViewPart3.setOnClickListener {
            imageViewPart3.rotation = (imageViewPart3.rotation + 90) % 360
        }
        imageViewPart4.setOnClickListener {
            imageViewPart4.rotation = (imageViewPart4.rotation + 90) % 360
        }
    }

}